#ifndef SINE_LIST
#define	SINE_LIST

#include <xc.h> 

typedef struct sine_node{
    short item;
    struct sine_node* next;
} Node;

//REQUIRES: head points to a real Node, value is a valid short
//PROMISES:
//          Allocated memory to create a new node with item being value. 
//          Adds the new node to the end of the list.
void SL_push(Node* head, short value);

//REQUIRES: array points to a valid array of type short with n elements such that 
//          array[0]...array[n-1] exists
//PROMISES:
//          Creates a list of linked nodes with length equal to length of array.
//          Populates each node's item with the values in each element of the array.
//          Links the last item in the list to the head of the array.
Node* SL_populate(const short* array, int n);


#endif

