#include <pic.h>
#include "Timer2.h"

// REQUIRES: Nothing
// PROMISES: Configure Timer4 as a one-shot with a 0.5us tick rate.
//           Configure Timer6 as a one-shot with a 484us tick rate.
//           Both timers are off.
void Timer_Init(void)
{    
    // TxCLKCON: TIMERx CLOCK SELECTION REGISTER (Page 306)
    T4CLKCON = 0x03;        // Timer4: Clock source is HFOSC (32MHz)
    //T6CLKCON = 0x05;        // Timer6: Clock source is MFOSC (500kHz)
    
    // TxCON: TIMERx CONTROL REGISTER (Page 307)
    T4CON = 0x30;           // Timer4: Prescaler = 32, Postscaler = 1
    //T6CON = 0x50;           // Timer6: Prescaler = 2, Postscaler = 15
    
    // T2HLT: TxHLT: TIMERx HARDWARE LIMIT CONTROL REGISTER (Page 308)
    T4HLT = 0x08;           // Timer4: One-shot mode. (No auto-restart)
    //T6HLT = 0x08;           // Timer6: One-shot mode. (No auto-restart)
    
    return;
}

