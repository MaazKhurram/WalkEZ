#include "Sine_List.h"
#include <xc.h>


void SL_push(Node* head, short value)
{
    Node* current = head;
    while(current->next!=NULL)
    {
        current = current->next;
    }
    current->next = malloc(sizeof(Node));
    if(current->next == NULL)
        return;
    current->next->item = value;
    current->next->next = NULL;
}

Node* SL_populate(const short* array,int n)
{
    Node* head = Node(0);
    if(head==NULL)
        return NULL;
    Node *current = head;
    for(int i = 0; i<n;i++)
    {
        if(current==head)
        {
            current->item = array[i];
        }
        else
        {
            current = malloc(sizeof(Node));
            if(current==NULL)
                return NULL;
        }
        current->next=NULL;
        current = current->next;
    }
    return head;
}
