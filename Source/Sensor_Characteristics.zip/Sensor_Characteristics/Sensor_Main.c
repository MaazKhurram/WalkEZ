#include <pic.h>
#include <pic16f1778.h>
#include "Lab3_Config.h"
#include "Timer.h"
//#include "Sine_List.h"

#define OutputPin PORTBbits.RB0 //trig RC2
#define InputPin PORTBbits.RB1  //echo RC3
#define PLAY_AUDIO()                        \
{                                           \
    if (ArrayIndex == 200)                  \
        ArrayIndex = 0;                     \
    audio_output = array200[ArrayIndex++];  \
    write2DAC(audio_output);                \
    TIMER2_WAIT();                          \
}                                           




short SineArray(void);
//REQUIRES:
//          WriteValue is between 0 - 1023
//PROMISES:
//          writes value of WriteValue to the DAC1REFH and DAC1REFL such that 
//          WriteValue is written to the output of DAC1
void write2DAC(short WriteValue);


static short audio_output; 
static char ArrayIndex = 0;

void main(void) {

    const short Array[] = 
        {500, 531, 563, 594, 624, 655, 684, 713, 741, 768,
         794, 819, 842, 864, 885, 905, 922, 938, 952, 965, 
         976, 984, 991, 996, 999,1000, 999, 996, 991, 984,
         976, 965, 952, 938, 922, 905, 885, 864, 842, 819,
         794, 768, 741, 713, 684, 655, 624, 594, 563, 531,
         500, 469, 437, 406, 376, 345, 316, 287, 259, 232,
         206, 181, 158, 136, 115,  95,  78,  62,  48,  35,
          24,  16,   9,   4,   1,   0,   1,   4,   9,  16, 
          24,  35,  48,  62,  78,  95, 115, 136, 158, 181, 
         206, 232, 259, 287, 316, 345, 376, 406, 437, 469};
    
    const short array50[] = 
        {512,576,639,700,758,812,862,906,943,974,998,1014,1022,
        1022,1014,998,974,943,906,862,812,758,700,639,576,512,447,
        384,323,265,211,161,117,80,49,25,9,1,1,9,25,49,80,117,161,
        211,265,323,384,447,512};
    
    const short array200[] = 
        {512,528,544,560,576,592,607,623,639,654,670,685,700,715,
        729,744,758,772,786,799,812,825,838,850,862,873,884,895,
        906,916,925,935,943,952,960,967,974,981,987,993,998,1003,
        1007,1011,1014,1017,1019,1021,1022,1023,1023,1023,1022,1021,
        1019,1017,1014,1011,1007,1003,998,993,987,981,974,967,960,952,
        943,935,925,916,906,895,884,873,862,850,838,825,812,799,786,772,
        758,744,729,715,700,685,670,654,639,623,607,592,576,560,544,528,
        512,495,479,463,447,431,416,400,384,369,353,338,323,308,294,279,
        265,251,237,224,211,198,185,173,161,150,139,128,117,107,98,88,80,
        71,63,56,49,42,36,30,25,20,16,12,9,6,4,2,1,0,0,0,1,2,4,6,9,12,16,20,
        25,30,36,42,49,56,63,71,80,88,98,107,117,128,139,150,161,173,185,198,
        211,224,237,251,265,279,294,308,323,338,353,369,384,400,416,431,447,
        463,479,495,512};
    
    
    //Node* head = SL_populate(array200,201);
    // Set the system clock speed to 32MHz and wait for the ready flag.
    OSCCON = 0xF4;
    while(OSCSTATbits.HFIOFR == 0);
    //Initialize the Digital to Analog Converter
    TRISBbits.TRISB0=0;
    TRISBbits.TRISB1=1;
    ANSELBbits.ANSB0=0;
    ANSELBbits.ANSB1=0;

    TRISA = 251;
    DAC1CON0 = 160;

    long unsigned int duration=0;
    
    ConfigureTimer1();
    ConfigureTimer2();
    ConfigureTimer4();
    
    /*
    ConfigureTimer2(250);

    OutputPin = 0;
    while(PIR1bits.TMR2IF==0);
    PIR1bits.TMR2IF=0;
    OutputPin = 1;
    while(PIR1bits.TMR2IF==0);
    PIR1bits.TMR2IF=0;
    OutputPin=0;
    __nop();
    while(1){
     if (ArrayIndex == 50) 
            ArrayIndex = 0;
        audio_output = array50[ArrayIndex++];
        write2DAC(audio_output);
        while(!PIR1bits.TMR2IF);
        PIR1bits.TMR2IF=0;
    __nop();
    }
    */
    audio_output=0;
    
    while(1)
    {
            OutputPin = 0;
            TIMER4_START(20);
            TIMER4_WAIT();

            OutputPin = 1;
            TIMER4_START(20);
            TIMER4_WAIT();

            OutputPin = 0;
            __nop();
            while(InputPin == 0)
            {
                PLAY_AUDIO();
            }

            TIMER1_START();
            while((PIR1bits.TMR1IF==0) && (InputPin == 1) )
            {
                PLAY_AUDIO();
            }

            duration = TMR1H;
            duration = (duration<<8)+TMR1L;

            
            long unsigned int timer2p=(duration << 4)+(duration<<2);
            timer2p =timer2p>>10;
            if(timer2p<255)
            {
                TIMER2_START((char)timer2p);
            }
            else
            {
                PIR1bits.TMR2IF=1;
            }

            while(PIR1bits.TMR1IF==0)
            {
                PLAY_AUDIO();
            }
        
    }
      
}


void write2DAC(short WriteValue)
{
    DAC1REFH = WriteValue>>8;
    short temp = WriteValue<<8;
    DAC1REFL = temp>>8;
    DACLDbits.DAC1LD = 1;
}
 