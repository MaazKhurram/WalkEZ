#ifndef PAUL_TIMER_H
#define	PAUL_TIMER_H

/* ---------------------------- Global Variables ---------------------------- */



/* -------------------------- Function Prototypes --------------------------- */

// REQUIRES: Nothing
// PROMISES: Configure Timer4 as a one-shot with a 0.5us tick rate.
//           Configure Timer6 as a one-shot with a 484us tick rate.
//           Both timers are off.
void Timer_Init(void);

/* ------------------- Macro-Based Function Declarations -------------------- */
#define TIMER4_START(period){   \
    T4PR = period;              \
    PIR4bits.TMR4IF = 0;        \
    T4CONbits.ON = 1;           \
}

#define TIMER6_START(period){   \
    T6PR = period;              \
    PIR4bits.TMR6IF = 0;        \
    T6CONbits.ON = 1;           \
}

#define TIMER4_WAIT(){          \
    while(!PIR4bits.TMR4IF);     \
    PIR4bits.TMR4IF = 0;        \
}

#define TIMER6_WAIT(){          \
    while(!PIR4bits.TMR6IF);     \
    PIR4bits.TMR6IF = 0;        \
}

#endif	/* PAUL_TIMER_H */

